﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RctByTN.Model
{
        public enum GuestStatus
        {
            Searching,
            Waiting,
            Busy,
            Aimless
        }
}
