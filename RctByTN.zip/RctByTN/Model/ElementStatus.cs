﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RctByTN.Model
{
    public enum ElementStatus
    {
        Operate,
        InWaiting,
        InBuild
    }
}
